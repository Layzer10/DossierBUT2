<?php
// Connexion à la base
$pdo = new PDO('mysql:host=localhost;dbname=produits;charset=utf8', 'root', '');
