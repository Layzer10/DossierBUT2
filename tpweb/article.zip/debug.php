<?php
    function display($a)
    {
        echo "<pre>";
        print_r($a);
        echo "</pre>";
    }

    function display2($a)
    {
        echo "<pre>";
        print_r($a);
        echo "</pre>";
    }